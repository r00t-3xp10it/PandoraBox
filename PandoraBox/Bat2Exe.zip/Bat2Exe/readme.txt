-- Bat2Exe --
Windows only user interface for converting your batch files into executables - with multiple options.
Github Link: https://github.com/dehoisted/Bat2Exe (open source)

-- Example(s) --
View this link for generated EXE's using Bat2Exe: https://github.com/dehoisted/Bat2Exe/tree/main/Example

-- Update Log --
+ Updated UI
+ Fixed update checking
+ Improved batch parsing
+ Added batch obfuscation (2 methods)
+ Fixed minor errors

-- Dependencies -- (do not delete these files.)
Guna.UI2.dll is the library used for the UI.
bytepress.exe is used to compress your generated exe file, so there is no need to run it. (along with NDesk.Options.dll and bytepress.lib.dll)

Version: 2.0
Last Update: 9/17/2021